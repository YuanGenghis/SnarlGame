import javafx.util.Pair;

public class Hallway {
  char[][] layout;
  Pair<Integer, Integer> position;
  Pair<Pair<Integer, Integer>, Pair<Integer, Integer>> connection;

  public Hallway(char[][] tiles, Pair<Integer, Integer> position,
                 Pair<Pair<Integer, Integer>, Pair<Integer, Integer>> connection) {
    this.layout = tiles;
    this.position = position;
    this.connection = connection;
  }

}
