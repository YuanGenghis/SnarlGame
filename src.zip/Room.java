import javafx.util.Pair;

public class Room {
  char[][] layout;
  Pair<Integer, Integer> position;

  public Room(char[][] tiles, Pair<Integer, Integer> position) {
    this.layout = tiles;
    this.position = position;
  }



}
